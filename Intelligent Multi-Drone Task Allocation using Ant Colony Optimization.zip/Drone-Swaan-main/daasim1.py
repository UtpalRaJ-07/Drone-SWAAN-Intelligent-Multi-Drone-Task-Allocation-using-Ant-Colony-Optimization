import tkinter as tk
import numpy as np
import random
import time
import math
import heapq
from PIL import Image, ImageTk


grid_size = (5, 5)
cell_size = 100  
obstacles = [(1, 1), (2, 1), (3, 3)]
tasks = {'Task A': (0, 4), 'Task B': (4, 0), 'Task C': (4, 4)}
drones = [{'id': 0, 'position': (0, 0), 'battery': 100, 'task': 'Task A', 'start_time': time.time()},
          {'id': 1, 'position': (4, 4), 'battery': 100, 'task': 'Task B', 'start_time': time.time()}]
dynamic_obstacles = [(2, 2), (3, 0)]



class AStar:
    def __init__(self, grid):
        self.grid = grid

    def find_path(self, start, goal):
        """ A* pathfinding algorithm """
        open_list = []
        closed_list = set()
        came_from = {}

        g_score = {start: 0}
        f_score = {start: self.heuristic(start, goal)}

        heapq.heappush(open_list, (f_score[start], start))

        while open_list:
            _, current = heapq.heappop(open_list)

            if current == goal:
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(start)
                path.reverse()
                return path

            closed_list.add(current)

            for neighbor in self.get_neighbors(current):
                if neighbor in closed_list or self.grid[neighbor[0]][neighbor[1]] == 1: 
                    continue

                tentative_g_score = g_score[current] + 1
                if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score[neighbor] = tentative_g_score + self.heuristic(neighbor, goal)
                    heapq.heappush(open_list, (f_score[neighbor], neighbor))

        return None 

    def heuristic(self, current, goal):
        """ Heuristic function: Manhattan distance """
        return abs(current[0] - goal[0]) + abs(current[1] - goal[1])

    def get_neighbors(self, node):
        x, y = node
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        neighbors = [(x + dx, y + dy) for dx, dy in directions if 0 <= x + dx < len(self.grid) and 0 <= y + dy < len(self.grid[0])]
        return neighbors



class DroneSimulationUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Drone Simulation")
        self.grid_size = grid_size
        self.cell_size = cell_size
        self.canvas = tk.Canvas(self.root, width=grid_size[1] * cell_size, height=grid_size[0] * cell_size)
        self.canvas.grid(row=0, column=0)

       
        self.grid_cells = {}
        self.grid = np.zeros(self.grid_size)
        for x, y in obstacles:
            self.grid[x][y] = 1  

        self.a_star = AStar(self.grid)

      
        self.dynamic_obstacles = dynamic_obstacles

      
        self.drone_images = {
            0: ImageTk.PhotoImage(Image.open("./drone.jpeg").resize((50, 50), Image.Resampling.LANCZOS)),
            1: ImageTk.PhotoImage(Image.open("./drone.jpeg").resize((50, 50), Image.Resampling.LANCZOS))
        }
        self.drone_graphics = {} 

     
        self.create_grid_ui()

        self.output_box = tk.Text(self.root, width=70, height=20)
        self.output_box.grid(row=0, column=1, padx=10, pady=10)

        self.current_step = 0
        self.drone_paths = {}
        self.drone_task_status = {}
        self.total_simulation_start_time = time.time()
        self.obstacles_faced = {drone['id']: 0 for drone in drones}

    def create_grid_ui(self):
        """ Create a grid on the canvas """
        for i in range(self.grid_size[0]):
            for j in range(self.grid_size[1]):
                self.grid_cells[(i, j)] = self.canvas.create_rectangle(
                    j * self.cell_size, i * self.cell_size, 
                    (j + 1) * self.cell_size, (i + 1) * self.cell_size,
                    outline="gray", fill="white"
                )
        self.update_grid()

    def update_grid(self):
        """ Update the grid with drones, obstacles, and tasks """
       
        for drone_id in self.drone_graphics.values():
            self.canvas.delete(drone_id)
        self.drone_graphics.clear()

        for i in range(self.grid_size[0]):
            for j in range(self.grid_size[1]):
                if (i, j) in obstacles:
                    self.canvas.itemconfig(self.grid_cells[(i, j)], fill="black")
                elif (i, j) in self.dynamic_obstacles:
                    self.canvas.itemconfig(self.grid_cells[(i, j)], fill="red")
                elif (i, j) in tasks.values():
                    self.canvas.itemconfig(self.grid_cells[(i, j)], fill="green")
                else:
                    self.canvas.itemconfig(self.grid_cells[(i, j)], fill="white")

       
        for drone in drones:
            x, y = drone['position']
            drone_image = self.drone_images[drone['id']]
            self.drone_graphics[drone['id']] = self.canvas.create_image(
                y * self.cell_size + self.cell_size // 2, x * self.cell_size + self.cell_size // 2, 
                image=drone_image, anchor=tk.CENTER
            )

    def start_simulation(self):
        """ Start the simulation """
        self.current_step = 0
        self.drone_paths = {}

        
        for drone in drones:
            task_position = tasks[drone['task']]
            start = drone['position']
            path = self.a_star.find_path(start, task_position)
            if path:
                self.drone_paths[drone['id']] = path

       
        self.move_drones_step_by_step()

    def move_drones_step_by_step(self):
        """ Move drones step by step with a delay """
        if self.current_step >= max(len(path) for path in self.drone_paths.values()):
            self.show_completion()
            return
        for drone in drones:
            if drone['id'] in self.drone_paths and self.current_step < len(self.drone_paths[drone['id']]):
                path_step = self.drone_paths[drone['id']][self.current_step]
                drone['position'] = path_step

                
                if path_step in obstacles or path_step in self.dynamic_obstacles:
                    self.obstacles_faced[drone['id']] += 1

        self.update_grid()
        self.current_step += 1
        self.root.after(1000, self.move_drones_step_by_step)

    def show_completion(self):
        """ Display task completion summary in the output box """
        total_simulation_end_time = time.time()
        total_simulation_time = total_simulation_end_time - self.total_simulation_start_time

        paths_output = "\n".join([f"Drone {drone['id']} Path to {drone['task']}: {self.drone_paths[drone['id']]}" for drone in drones])
        task_assignments = "\n".join([f"Drone {drone['id']} is assigned to Task {drone['task']}" for drone in drones])
        task_completion_summary = "\n".join([f"Task {drone['task']} was completed by Drone {drone['id']} using A* algorithm"
                                             for drone in drones])
        obstacles_faced_output = "\n".join([f"Drone {drone['id']} faced {self.obstacles_faced[drone['id']]} obstacles."
                                             for drone in drones])

        self.output_box.delete(1.0, tk.END)
        self.output_box.insert(tk.END, f"Simulation Time: {total_simulation_time:.2f} seconds\n")
        self.output_box.insert(tk.END, paths_output + "\n")
        self.output_box.insert(tk.END, task_assignments + "\n")
        self.output_box.insert(tk.END, task_completion_summary + "\n")
        self.output_box.insert(tk.END, obstacles_faced_output + "\n")


if __name__ == "__main__":
    root = tk.Tk()
    simulation = DroneSimulationUI(root)
    start_button = tk.Button(root, text="Start Simulation", command=simulation.start_simulation)
    start_button.grid(row=1, column=0, pady=10)
    root.mainloop()
