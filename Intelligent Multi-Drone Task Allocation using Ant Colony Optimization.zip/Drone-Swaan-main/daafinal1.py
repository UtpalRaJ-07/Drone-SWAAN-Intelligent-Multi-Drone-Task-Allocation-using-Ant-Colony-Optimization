import tkinter as tk
import numpy as np
import random
import time


grid_size = (5, 5)
obstacles = [(1, 1), (2, 1), (3, 3)]
tasks = {'Task A': (0, 4), 'Task B': (4, 0), 'Task C': (4, 4)}
drones = [{'id': 0, 'position': (0, 0), 'battery': 100, 'task': 'Task A', 'start_time': time.time()},
          {'id': 1, 'position': (4, 4), 'battery': 100, 'task': 'Task B', 'start_time': time.time()}]


dynamic_obstacles = [(2, 2), (3, 0)]


class AntColony:
    def __init__(self, grid, alpha=1.0, beta=2.0, evaporation_rate=0.5):
        self.grid = grid
        self.alpha = alpha
        self.beta = beta
        self.evaporation_rate = evaporation_rate
        self.pheromone_map = np.ones_like(grid, dtype=float)

    def find_path(self, start, goal):
        rows, cols = len(self.grid), len(self.grid[0])
        paths = []
        for _ in range(10):  # Simulate multiple ants
            path, cost = self._simulate_ant(start, goal)
            if path:
                paths.append((path, cost))
        if paths:
            best_path = min(paths, key=lambda x: x[1])
            self._update_pheromones(best_path[0])
            return best_path[0]
        return None

    def _simulate_ant(self, start, goal):
        current = start
        path = [current]
        cost = 0
        while current != goal:
            neighbors = self._get_neighbors(current)
            if not neighbors:
                return None, float('inf')
            probabilities = self._calculate_probabilities(current, neighbors, goal)
            current = random.choices(neighbors, probabilities)[0]
            path.append(current)
            cost += 1
        return path, cost

    def _get_neighbors(self, node):
        x, y = node
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        neighbors = [(x + dx, y + dy) for dx, dy in directions if 0 <= x + dx < len(self.grid) and 0 <= y + dy < len(self.grid[0])]
        return [n for n in neighbors if self.grid[n[0]][n[1]] == 0]

    def _calculate_probabilities(self, current, neighbors, goal):
        probabilities = []
        for neighbor in neighbors:
            heuristic = 1 / (1 + np.linalg.norm(np.array(goal) - np.array(neighbor)))
            pheromone = self.pheromone_map[neighbor[0]][neighbor[1]]
            probabilities.append((pheromone ** self.alpha) * (heuristic ** self.beta))
        total = sum(probabilities)
        return [p / total for p in probabilities]

    def _update_pheromones(self, path):
        for x, y in path:
            self.pheromone_map[x][y] += 1
        self.pheromone_map *= (1 - self.evaporation_rate)


class DroneSimulationUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Drone Simulation")
        self.grid_size = grid_size
        self.canvas = tk.Canvas(self.root, width=300, height=300)
        self.canvas.grid(row=0, column=0)

        self.bg_image = tk.PhotoImage(file="./map.png")  
        self.canvas.create_image(0, 0, anchor="nw", image=self.bg_image)

        self.grid_cells = {}
        self.grid = np.zeros(self.grid_size)
        for x, y in obstacles:
            self.grid[x][y] = 1

        self.ant_colony = AntColony(self.grid)
        self.dynamic_obstacles = dynamic_obstacles

        self.create_grid_ui()

        self.output_box = tk.Text(self.root, width=70, height=20)
        self.output_box.grid(row=0, column=1, padx=10, pady=10)

        self.current_step = 0
        self.drone_paths = {}
        self.drone_task_status = {}
        self.total_simulation_start_time = time.time()
        self.obstacles_faced = {drone['id']: 0 for drone in drones}

    def create_grid_ui(self):
        """ Create a grid of labels on the canvas to display drone simulation """
        for i in range(self.grid_size[0]):
            for j in range(self.grid_size[1]):
                self.grid_cells[(i, j)] = self.canvas.create_text(
                    j * 60 + 30, i * 60 + 30, text='.', font=('Arial', 18, 'bold'), fill='black'
                )
        self.update_grid()

    def update_grid(self):
        """ Update the grid with the current state of drones, obstacles, and tasks """
        for i in range(self.grid_size[0]):
            for j in range(self.grid_size[1]):

                symbol = '.'

                if (i, j) in obstacles:
                    symbol = 'X'
                elif (i, j) in self.dynamic_obstacles:
                    symbol = 'D'
                elif any(drone['position'] == (i, j) for drone in drones):
                    symbol = 'O'
                elif (i, j) in tasks.values():
                    symbol = 'T'

                self.canvas.itemconfig(self.grid_cells[(i, j)], text=symbol)

    def start_simulation(self):
        """ Start the simulation and animate drone movement step by step """
        self.current_step = 0
        self.drone_paths = {}

        for drone in drones:
            task_position = tasks[drone['task']]
            start = drone['position']
            path = self.ant_colony.find_path(start, task_position)
            if path:
                self.drone_paths[drone['id']] = path

        self.move_drones_step_by_step()

    def move_drones_step_by_step(self):
        """ Move drones step by step with a delay """
        if self.current_step >= max(len(path) for path in self.drone_paths.values()):
            self.show_completion()
            return
        for drone in drones:
            if drone['id'] in self.drone_paths and self.current_step < len(self.drone_paths[drone['id']]):
                path_step = self.drone_paths[drone['id']][self.current_step]
                drone['position'] = path_step

                if path_step in obstacles or path_step in self.dynamic_obstacles:
                    self.obstacles_faced[drone['id']] += 1

        self.update_grid()
        self.current_step += 1
        self.root.after(1000, self.move_drones_step_by_step)

    def show_completion(self):
        """ Display task completion summary in the output box """
        total_simulation_end_time = time.time()
        total_simulation_time = total_simulation_end_time - self.total_simulation_start_time

        paths_output = "\n".join([f"Drone {drone['id']} Path to {drone['task']}: {self.drone_paths[drone['id']]}" for drone in drones])

        task_assignments = "\n".join([f"Drone {drone['id']} is assigned to Task {drone['task']}" for drone in drones])

        task_completion_summary = "\n".join([f"Task {drone['task']} was completed by Drone {drone['id']} using A* in {self.calculate_task_time(drone['start_time'])} seconds."
                                             for drone in drones])

        obstacles_output = "\n".join([f"Drone {drone['id']} faced {self.obstacles_faced[drone['id']]} obstacles." for drone in drones])

        real_time_status = "\n".join([f"Drone {drone['id']} - Position: {drone['position']}, Battery: {drone['battery']}%, Obstacles Faced: {self.obstacles_faced[drone['id']]}" for drone in drones])

        total_time_taken = "\n".join([f"Drone {drone['id']} took {self.calculate_task_time(drone['start_time'])} seconds to complete assigned tasks." for drone in drones])

        self.output_box.delete(1.0, tk.END)
        self.output_box.insert(tk.END, f"Paths:\n{paths_output}\n\nTask Assignments:\n{task_assignments}\n\nTask Completion Summary:\n{task_completion_summary}\n\n")
        self.output_box.insert(tk.END, f"Obstacles Faced by Drones:\n{obstacles_output}\n\nReal-Time Drone Status:\n{real_time_status}\n\n")
        self.output_box.insert(tk.END, f"Total Time Taken by Drones:\n{total_time_taken}\n\n")
        self.output_box.insert(tk.END, f"Total Time Taken to Execute Simulation: {total_simulation_time:.5f} seconds")

    def calculate_task_time(self, start_time):
        """ Calculate the time taken for a drone to complete a task """
        return time.time() - start_time


if __name__ == "__main__":
    root = tk.Tk()
    ui = DroneSimulationUI(root)
    ui.start_simulation()
    root.mainloop()
